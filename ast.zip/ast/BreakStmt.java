package ast;

// Stmt -> 'break' ';'
public class BreakStmt extends StmtNode {
}
