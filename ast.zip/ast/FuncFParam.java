package ast;

// FuncFParam -> BType Ident ['[' ']']
public class FuncFParam extends Node{
    public String paramName;
    public boolean isArray;
}
