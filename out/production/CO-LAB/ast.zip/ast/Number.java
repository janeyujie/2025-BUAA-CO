package ast;

// Number -> IntConst
public class Number extends ExprNode {
    public int value;
}
