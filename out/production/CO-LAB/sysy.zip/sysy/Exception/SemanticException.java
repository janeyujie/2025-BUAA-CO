package sysy.Exception;

public class SemanticException extends Exception {
    public SemanticException(String message) {
        super(message);
    }
}
