import frontend.Lexer;
import frontend.Token;
import frontend.TokenType;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Compiler {

    private final String sourceCode;
    private Lexer lexer;
    private String output = "";

    public Compiler(String sourceCode) {
        this.sourceCode = sourceCode;
        this.lexer = new Lexer(sourceCode);
    }

    public void compile() {
        // 词法分析
        Token token = lexer.getNextToken();
        while (true) {
            //System.out.println(token);
            if (token.getType() == TokenType.ANNOSY) {
                token = lexer.getNextToken();
                continue;
            }

            if (token.getType() == TokenType.EOFSY)
                break;

            if (token.getType() == TokenType.ERRORSY) {
                output = token.toError();
                break;
            }
            // 注意token的输出方式
            output += token.toString();
            token = lexer.getNextToken();
        }
    }

    public static void main(String[] args) {
        String inputPath = "testfile.txt";
        String outputPath = "lexer.txt";
        try {
            String sourceCode = new String(Files.readAllBytes(Paths.get(inputPath)));
            //System.out.println(sourceCode);
            Compiler compiler = new Compiler(sourceCode);
            compiler.compile();

            Files.write(Paths.get(outputPath), compiler.output.getBytes());
            //System.out.print(compiler.output);
        } catch (IOException e) {
            System.err.println("Error reading or writing file: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Compilation Error: " + e.getMessage());
        }

    }
}
