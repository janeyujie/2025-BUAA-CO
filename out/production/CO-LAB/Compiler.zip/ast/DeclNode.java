package ast;

// 声明节点
public abstract class DeclNode extends Node {
}
