package sysy.backend.MipsInstruction;

import java.util.List;

// 二元运算: add $t0, $t1, $t2
public class MipsBinary extends MipsInstruction {
    public String op, rd, rs, rt;

    public MipsBinary(String op, String rd, String rs, String rt) {
        this.op = op;
        this.rd = rd;
        this.rs = rs;
        this.rt = rt;
    }

    @Override
    public java.util.List<String> mipsOutput() {
        return List.of(String.format("%s %s, %s, %s", op, rd, rs, rt));
    }
}
