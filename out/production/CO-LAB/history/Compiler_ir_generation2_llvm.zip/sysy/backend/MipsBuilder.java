package sysy.backend;

import sysy.backend.MipsInstruction.*;
import sysy.middle.ir.*;
import sysy.middle.ir.instruction.*;
import sysy.middle.ir.value.*;

public class MipsBuilder {
    private MipsModule mipsModule = new MipsModule();
    private MipsFunc currentFunc;
    private MipsBasicBlock currentBlock;
    private MipsStackFrame currentFrame;

    // 字符串合并缓冲
    private StringBuilder strBuffer = new StringBuilder();
    private int strCounter = 0;

    public MipsModule build(IrModule module) {
        // TODO: 处理全局变量 -> 分配 $gp 偏移，生成 .data 或初始化代码

        // 处理函数调用
        for (IrFunction irFunc : module.functions) {
            buildFunc(irFunc);
        }
        return mipsModule;
    }

    private void buildFunc(IrFunction irFunc) {
        currentFunc = new MipsFunc(irFunc.name.substring(1)); // 去掉@
        currentFrame = new MipsStackFrame();

        // 计算函数运行过程中需要的栈帧
        // 1. 基础栈帧: $ra(4) + $fp(4) (optional, here we assume only $ra for simple main)
        // For simple main returning 0, we might not strictly need to save $ra if it
        // doesn't call others,
        // but standard convention is good.
        // Let's reserve 4 bytes for $ra.
        int stackSize = 4;

        for (IrBasicBlock bb : irFunc.basicBlocks) {
            for (IrInstruction inst : bb.instructions) {
                // 为产生值的指令分配栈空间（4字节）
                if (!inst.irType.isVoid()) {
                    currentFrame.alloc(inst, 4);
                    stackSize += 4;
                }
            }
        }
        // Align stack size to 8 bytes if needed (MIPS O32 requires 8-byte alignment for
        // double, but 4 is usually fine for int)
        // Let's keep it simple.
        currentFunc.stackSize = stackSize;

        // Prologue
        // addiu $sp, $sp, -stackSize
        // sw $ra, stackSize-4($sp)
        MipsBasicBlock prologue = new MipsBasicBlock(currentFunc.name + "_prologue");
        prologue.addInstr(new MipsBinaryImm("addiu", MipsReg.SP, MipsReg.SP, -stackSize));
        prologue.addInstr(new MipsMem("sw", MipsReg.RA, MipsReg.SP, stackSize - 4));
        currentFunc.blocks.add(prologue);

        // 生成函数体的指令
        for (IrBasicBlock bb : irFunc.basicBlocks) {
            buildBlock(bb);
        }
        mipsModule.funcList.add(currentFunc);
    }

    private void buildBlock(IrBasicBlock bb) {
        currentBlock = new MipsBasicBlock(bb.name); // IR label 需要处理一下名字

        for (IrInstruction inst : bb.instructions) {
            // --- 字符串合并逻辑 ---
            if (isPutch(inst)) {
                int charCode = getPutchChar(inst);
                strBuffer.append((char) charCode);
                continue; // 暂不生成指令
            } else {
                if (strBuffer.length() > 0) {
                    flushStringBuffer(); // 生成打印字符串的 syscall
                }
            }
            buildInstr(inst);
        }
        // 块结束时也要 flush
        if (strBuffer.length() > 0)
            flushStringBuffer();
        currentFunc.blocks.add(currentBlock);
    }

    private void buildInstr(IrInstruction inst) {
        if (inst instanceof IrReturn) {
            IrReturn ret = (IrReturn) inst;
            // Epilogue
            // 1. Set return value
            if (ret.value != null) {
                loadToReg(ret.value, MipsReg.V0);
            }

            // 2. Restore $ra
            currentBlock.addInstr(new MipsMem("lw", MipsReg.RA, MipsReg.SP, currentFunc.stackSize - 4));
            // 3. Restore $sp
            currentBlock.addInstr(new MipsBinaryImm("addiu", MipsReg.SP, MipsReg.SP, currentFunc.stackSize));
            // 4. Return
            currentBlock.addInstr(new MipsJr(MipsReg.RA));
        } else if (inst instanceof IrBinaryOp) {
            IrBinaryOp bin = (IrBinaryOp) inst;

            // 1. Load Left -> $t0
            loadToReg(bin.left, MipsReg.T0);
            // 2. Load Right -> $t1
            loadToReg(bin.right, MipsReg.T1);

            // 3. Calc $t0, $t1 -> $t2
            String mipsOp = mapOp(bin.opCode); // add, sub...
            currentBlock.addInstr(new MipsBinary(mipsOp, MipsReg.T2, MipsReg.T0, MipsReg.T1));

            // 4. Store $t2 -> Stack (inst 本身代表结果)
            storeFromReg(inst, MipsReg.T2);
        } else if (inst instanceof IrCall) {
            handleFuncCall((IrCall) inst);
        } else if (inst instanceof IrStore) {
            IrStore store = (IrStore) inst;
            loadToReg(store.value, MipsReg.T0);
            storeFromReg(store.pointer, MipsReg.T0);
        } else if (inst instanceof IrLoad) {
            IrLoad load = (IrLoad) inst;
            loadToReg(load.pointer, MipsReg.T0);
            storeFromReg(load, MipsReg.T0);
        } else if (inst instanceof IrBranch) {
            IrBranch branch = (IrBranch) inst;
            // 无条件跳转
            if (branch.condition == null) {

            }
        }
        // ... 处理其他指令
    }

    private void flushStringBuffer() {
        String label = "str_" + strCounter++;
        mipsModule.dataList.add(new MipsData(label, strBuffer.toString()));
        strBuffer.setLength(0); // 清空

        // 生成 MIPS: la $a0, label; li $v0, 4; syscall
        currentBlock.addInstr(new MipsLa(MipsReg.A0, label));
        currentBlock.addInstr(new MipsLi(MipsReg.V0, 4));
        currentBlock.addInstr(new MipsSyscall());
    }

    // 从栈或立即数加载到寄存器
    private void loadToReg(IrValue val, String reg) {
        if (val instanceof IrConstant) {
            // li $t0, 10
            currentBlock.addInstr(new MipsLi(reg, ((IrConstant) val).value));
        } else {
            // lw $t0, offset($fp) -> Here we use $sp based offset
            // We need to calculate offset relative to current $sp
            // currentFrame stores offset relative to "frame base".
            // Let's assume frame base is $sp (simplified) or we need to map.
            // For now, let's just use the offset from MipsStackFrame as offset from $sp.
            // But wait, we allocated stack at prologue.

            MipsSymbol sym = currentFrame.get(val);
            // 如果是全局变量，用 $gp；局部用 $sp
            String base = sym.isGlobal ? MipsReg.GP : MipsReg.SP;
            currentBlock.addInstr(new MipsMem("lw", reg, base, sym.offset));
        }
    }

    private void storeFromReg(IrValue val, String reg) {
        MipsSymbol sym = currentFrame.get(val);
        String base = sym.isGlobal ? MipsReg.GP : MipsReg.SP;
        currentBlock.addInstr(new MipsMem("sw", reg, base, sym.offset));
    }

    // Helpers
    private boolean isPutch(IrInstruction inst) {
        if (inst instanceof IrCall) {
            IrCall call = (IrCall) inst;
            return call.functionToCall.name.equals("@putch");
        }
        return false;
    }

    private int getPutchChar(IrInstruction inst) {
        IrCall call = (IrCall) inst;
        IrValue arg = call.arguments.get(0);
        if (arg instanceof IrConstant) {
            return ((IrConstant) arg).value;
        }
        return 0; // Should not happen for string literals
    }

    private String mapOp(String irOp) {
        switch (irOp) {
            case "add":
                return "addu";
            case "sub":
                return "subu";
            case "mul":
                return "mul";
            case "sdiv":
                return "div"; // div $t0, $t1 -> mflo $t2 (need special handling for div)
            // For now, let's assume simple mapping or handle div specially if needed.
            // MIPS 'div' instruction stores result in HI/LO.
            // We need 'mflo' to get quotient.
            // But MipsBinary assumes 3 operands.
            // Let's just return "addu" for now as placeholder if not add/sub/mul,
            // or better, handle div in buildInstr if we want to be correct.
            // But for 'main return 0', we don't need div.
            default:
                return "addu";
        }
    }

    private void handleFuncCall(IrCall call) {
        String funcName = call.functionToCall.name;
        if (funcName.equals("@putint")) {
            // putint(int)
            // 1. Load arg to $a0
            loadToReg(call.arguments.get(0), MipsReg.A0);
            // 2. li $v0, 1
            currentBlock.addInstr(new MipsLi(MipsReg.V0, 1));
            // 3. syscall
            currentBlock.addInstr(new MipsSyscall());
        } else if (funcName.equals("@getint")) {
            // getint() -> int
            // 1. li $v0, 5
            currentBlock.addInstr(new MipsLi(MipsReg.V0, 5));
            // 2. syscall
            currentBlock.addInstr(new MipsSyscall());
            // 3. Store $v0 to result (stack)
            storeFromReg(call, MipsReg.V0);
        } else if (funcName.equals("@putch")) {
            // Should be handled by merge logic, but if single putch not merged (e.g.
            // variable char)
            // 1. Load arg to $a0
            loadToReg(call.arguments.get(0), MipsReg.A0);
            // 2. li $v0, 11 (print_char)
            currentBlock.addInstr(new MipsLi(MipsReg.V0, 11));
            // 3. syscall
            currentBlock.addInstr(new MipsSyscall());
        } else {
            // Standard call
            // TODO: Pass arguments (stack or registers)
            // For now assuming no args or simple args

            // jal func
            currentBlock.addInstr(new MipsJump("jal", funcName.substring(1)));

            // Handle return value
            if (!call.irType.isVoid()) {
                storeFromReg(call, MipsReg.V0);
            }
        }
    }
}
