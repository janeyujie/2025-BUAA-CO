package sysy.backend;

import java.util.List;

public class MipsData implements MipsNode {
    public String label;
    public String content; // 需要打印的字符串

    public MipsData(String label, String content) {
        this.label = label;
        this.content = content;
    }

    @Override
    public List<String> mipsOutput() {
        // 做了转义字符的处理
        return List.of(label + ": .asciiz \"" + content.replace("\n", "\\n") + "\"");
    }
}
