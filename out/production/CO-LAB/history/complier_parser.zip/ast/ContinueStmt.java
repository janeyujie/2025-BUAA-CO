package ast;

public class ContinueStmt extends StmtNode {
}
