package ast;

// 语句节点
public abstract class StmtNode extends Node {
}
