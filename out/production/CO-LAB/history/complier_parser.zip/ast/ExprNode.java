package ast;

// 表达式节点
public class ExprNode extends Node {
}
