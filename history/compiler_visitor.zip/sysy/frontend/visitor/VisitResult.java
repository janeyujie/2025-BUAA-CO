package sysy.frontend.visitor;

import java.util.List;

public class VisitResult {
    public boolean ifArray;
    public boolean ifConst;
    public String returnType;
    public int number;
    public List<Integer> numbers;

}
